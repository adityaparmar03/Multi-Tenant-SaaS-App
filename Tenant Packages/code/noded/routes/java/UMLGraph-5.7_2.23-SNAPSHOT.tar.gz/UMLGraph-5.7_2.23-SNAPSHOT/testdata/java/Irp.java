class Application {}

class IrpApplication extends Application {}

/** @depend - <friend> - IrpApplication */
class Main {}
