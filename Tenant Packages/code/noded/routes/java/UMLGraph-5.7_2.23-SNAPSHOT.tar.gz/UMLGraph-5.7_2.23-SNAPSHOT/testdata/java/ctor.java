
/**
 * @opt all
 * @hidden
 */
class UMLOptions {}
 
class Junk {
    private int value;
    public Junk(int val){}
}
