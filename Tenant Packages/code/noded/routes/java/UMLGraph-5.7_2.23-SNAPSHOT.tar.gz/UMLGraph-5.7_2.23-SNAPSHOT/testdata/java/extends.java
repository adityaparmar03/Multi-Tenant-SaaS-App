
class Base {}
class Test2<B extends a.b.Base> {}
